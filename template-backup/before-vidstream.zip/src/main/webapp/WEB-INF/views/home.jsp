<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%><%@ taglib prefix="c"
	uri="jakarta.tags.core"%><!doctype html><html lang="vi"><head><meta charset="UTF-8"><title>Trang chủ</title></head><body>
<section class="hero">
	<p class="eyebrow">ĐỀ SỐ 03 · LẬP TRÌNH WEB</p>
	<h1>Kho video dành cho bạn</h1>
	<p>Khám phá các video mới theo từng danh mục.</p>
</section>
<c:forEach var="entry" items="${groups}">
	<section class="category">
		<div class="section-title">
			<h2>${entry.key.categoryName}</h2>
			<span>${counts[entry.key.categoryId]} video</span>
		</div>
		<div class="video-grid">
			<c:forEach var="v" items="${entry.value}">
				<article class="video-card">
					<a href="${pageContext.request.contextPath}/video?id=${v.videoId}"><img
						src="${v.poster}" alt="${v.title}"></a>
					<div class="card-body">
						<h3>${v.title}</h3>
						<dl>
							<dt>Mã video</dt>
							<dd>${v.videoId}</dd>
							<dt>Category</dt>
							<dd>${v.category.categoryName}</dd>
							<dt>View</dt>
							<dd>${v.views}</dd>
						</dl>
						<a class="button"
							href="${pageContext.request.contextPath}/video?id=${v.videoId}">Xem
							chi tiết</a>
					</div>
				</article>
			</c:forEach>
			<c:if test="${empty entry.value}">
				<p class="muted">Không còn video ở trang này.</p>
			</c:if>
		</div>
	</section>
</c:forEach>
<nav class="pagination">
	<c:if test="${page>1}">
		<a href="?page=${page-1}">&laquo;</a>
	</c:if>
	<c:forEach begin="1" end="${totalPages}" var="i">
		<a class="${i==page?'active':''}" href="?page=${i}">${i}</a>
	</c:forEach>
	<c:if test="${page<totalPages}">
		<a href="?page=${page+1}">&raquo;</a>
	</c:if>
</nav>
</body></html>

