<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%><!doctype html><html lang="vi"><head><meta charset="UTF-8"><title>Chi tiết video</title></head><body>
<article class="detail">
	<img src="${video.poster}" alt="${video.title}">
	<div>
		<p class="eyebrow">${video.category.categoryName}</p>
		<h1>${video.title}</h1>
		<dl class="detail-list">
			<dt>Mã video</dt>
			<dd>${video.videoId}</dd>
			<dt>Category name</dt>
			<dd>${video.category.categoryName}</dd>
			<dt>View</dt>
			<dd>${video.views}</dd>
			<dt>Share</dt>
			<dd>${shares}</dd>
			<dt>Like</dt>
			<dd>${likes}</dd>
		</dl>
		<p>${video.description}</p>
		<a class="button" href="${pageContext.request.contextPath}/home">Quay
			lại</a>
	</div>
</article>
</body></html>

