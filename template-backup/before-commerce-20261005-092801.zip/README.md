# Bài thi Lập trình Web - MSSV 24133056 - Đề 03

Ứng dụng Maven WAR dùng Servlet 6, JSP/JSTL, JPA/Hibernate và H2. Dữ liệu mẫu được tạo tự động lần chạy đầu.

## Chạy ứng dụng

1. Biên dịch bằng `mvn clean package`.
2. Triển khai `target/24133056.war` lên Tomcat 10.1+.
3. Truy cập `/24133056/`.

Tài khoản quản trị mẫu: `admin` / `123456`. Khi đăng ký, OTP được hiển thị trên màn hình xác thực để thuận tiện chấm bài (thời hạn 5 phút).

## Kiến trúc

- Presentation: Servlet, Filter, JSP; hai decorator dùng chung riêng cho User và Admin.
- Business: `AuthService`, `VideoService`.
- Data Access: các interface DAO và lớp cài đặt JPA.

## Giao diện VidStream

Giao diện được chuyển từ Blogy sang phong cách Cinema Modern của template Stitch: nền tối, điểm nhấn đỏ, banner video, danh mục và trang chi tiết. Dữ liệu và phân trang dùng các controller hiện có. Các trang tài khoản và quản trị dùng chung phong cách mới.

Bản sao giao diện trước khi thay nằm ở `template-backup/before-vidstream.zip`. Template mẫu chỉ có ảnh mô phỏng trình phát; ứng dụng hiện hiển thị poster và thống kê vì dữ liệu chưa có URL phát video.

## Khu vực quản trị CMS Studio

- `/admin` hoặc `/admin/dashboard`: tổng quan tài khoản, video, lượt xem, lượt thích/chia sẻ; biểu đồ lượt xem theo danh mục và top 5 video.
- `/admin/videos`: danh sách phân trang, thêm, sửa, xóa video. Các trang quản trị yêu cầu tài khoản admin.
- Số liệu là tổng tích lũy trong cơ sở dữ liệu, bao gồm video đang ẩn. Không mô phỏng doanh thu, CDN, lịch sử hoạt động hoặc dữ liệu theo ngày khi hệ thống chưa lưu các thông tin này.
- Giao diện dựa trên trang admin dashboard trong `stitch_video_platform_web_template1.zip`. Trang đăng nhập và thư viện cá nhân trong ZIP chưa được tích hợp trong lần bổ sung quản trị này.
- Bản sao trước thay đổi: `template-backup/before-admin-dashboard.zip`.
- Kiểm tra: Maven đóng gói WAR; Tomcat 10.1 biên dịch và trả HTTP 200 cho dashboard, quản lý video, decorator với dữ liệu mẫu và dữ liệu rỗng; kiểm tra mã hóa URL sửa video và escape tiêu đề. Chưa kiểm thử truy vấn thống kê với cơ sở dữ liệu đang chạy.
