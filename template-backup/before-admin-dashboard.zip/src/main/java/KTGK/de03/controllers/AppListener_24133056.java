package KTGK.de03.controllers;

import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import KTGK.de03.dao.JpaUtil_24133056;
import KTGK.de03.entity.*;
import KTGK.de03.service.PasswordUtil_24133056;

@WebListener
public class AppListener_24133056 implements ServletContextListener {
	public void contextInitialized(ServletContextEvent e) {
		EntityManager m = JpaUtil_24133056.em();
		EntityTransaction t = m.getTransaction();
		try {
			t.begin();
			if (m.find(User_24133056.class, "admin") == null)
				m.persist(new User_24133056("admin", PasswordUtil_24133056.hash("123456"), "Quản trị viên", "admin@24133056.local", true,
						true));
			Long n = m.createQuery("select count(c) from Category_24133056 c", Long.class).getSingleResult();
			if (n == 0) {
				String[] names = { "Lập trình", "Âm nhạc", "Giáo dục" };
				for (int k = 0; k < 3; k++) {
					Category_24133056 c = new Category_24133056(names[k], "CAT" + (k + 1));
					m.persist(c);
					for (int i = 1; i <= 7; i++) {
						String id = "V" + (k + 1) + String.format("%02d", i);
						m.persist(new Video_24133056(id, names[k] + " - Video " + i,
								"https://picsum.photos/seed/" + id + "/640/360", 100 * i, "Video minh họa cho đề số 03",
								c));
					}
				}
			}
			t.commit();
		} catch (RuntimeException x) {
			if (t.isActive())
				t.rollback();
			throw x;
		} finally {
			m.close();
		}
	}

	public void contextDestroyed(ServletContextEvent e) {
		JpaUtil_24133056.close();
	}
}




