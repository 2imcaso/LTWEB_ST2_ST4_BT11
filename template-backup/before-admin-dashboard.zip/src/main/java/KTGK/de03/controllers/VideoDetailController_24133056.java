package KTGK.de03.controllers;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import KTGK.de03.service.VideoService_24133056;

@WebServlet("/video")
public class VideoDetailController_24133056 extends BaseController_24133056 {
	private final VideoService_24133056 s = new VideoService_24133056();

	protected void doGet(HttpServletRequest r, HttpServletResponse p) {
		try {
			var v = s.find(r.getParameter("id")).orElse(null);
			if (v == null) {
				p.sendError(404);
				return;
			}
			r.setAttribute("video", v);
			r.setAttribute("likes", s.likes(v.getVideoId()));
			r.setAttribute("shares", s.shares(v.getVideoId()));
			view(r, p, "video-detail");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}




