package KTGK.de03.controllers;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import KTGK.de03.service.VideoService_24133056;
import java.util.*;

@WebServlet({ "/", "/home" })
public class HomeController_24133056 extends BaseController_24133056 {
	private final VideoService_24133056 s = new VideoService_24133056();

	protected void doGet(HttpServletRequest r, HttpServletResponse p) {
		try {
			int page = page(r);
			r.setAttribute("groups", s.home(page));
			Map<Integer, Long> counts = new HashMap<>();
			long max = 0;
			for (var c : s.categories()) {
				long n = s.countByCategory(c.getCategoryId());
				counts.put(c.getCategoryId(), n);
				max = Math.max(max, n);
			}
			r.setAttribute("counts", counts);
			r.setAttribute("page", page);
			r.setAttribute("totalPages", Math.max(1, (max + 2) / 3));
			view(r, p, "home");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}




