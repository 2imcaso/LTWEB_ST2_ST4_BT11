<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<!DOCTYPE html>
<html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><% out.write("<sitemesh:write property=\"title\"/>"); %> · VidStream</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Space+Grotesk:wght@600;700&amp;display=swap" rel="stylesheet">
<link href="${ctx}/assets/app.css" rel="stylesheet"><% out.write("<sitemesh:write property=\"head\"/>"); %>
</head><body>
<a class="skip-link" href="#main-content">Đến nội dung chính</a>
<header class="site-header">
 <div class="topline"><span><b class="live-dot">●</b> Khám phá thế giới video cùng VidStream</span><span>VIDEO PLATFORM · 24133056</span></div>
 <div class="header-row"><a class="brand" href="${ctx}/home"><span class="brand-icon">▶</span> Vid<span>Stream</span></a>
 <p class="header-caption">Không gian của những câu chuyện đáng xem.</p>
 <nav class="account-nav" aria-label="Tài khoản"><c:choose><c:when test="${empty sessionScope.user}"><a href="${ctx}/login">Đăng nhập</a><a class="button" href="${ctx}/register">Đăng ký</a></c:when><c:otherwise><span class="user-name"><c:out value="${sessionScope.user.fullname}"/></span><a href="${ctx}/logout">Đăng xuất</a></c:otherwise></c:choose><c:if test="${sessionScope.user.admin}"><a class="button" href="${ctx}/admin">Quản lý video</a></c:if></nav></div>
 <nav class="main-nav" aria-label="Điều hướng"><a href="${ctx}/home">Trang chủ</a><a href="${ctx}/home#categories">Khám phá danh mục</a></nav>
</header>
<main id="main-content" class="container"><% out.write("<sitemesh:write property=\"body\"/>"); %></main>
<footer><div class="footer-grid"><div><a class="brand" href="${ctx}/home">Vid<span>Stream</span></a><p>Nền tảng khám phá và chia sẻ video.<br>Kết nối tri thức, công nghệ và cảm hứng.</p></div><div><h3>Khám phá</h3><a href="${ctx}/home">Kho video</a><a href="${ctx}/home#categories">Danh mục video</a></div><div><h3>Thông tin sinh viên</h3><p>Bùi Phi Hùng<br>MSSV: 24133056 · Mã đề: 03</p></div></div><div class="footer-bottom">© VidStream · Video Platform <span>Thiết kế theo Cinema Modern</span></div></footer>
</body></html>
